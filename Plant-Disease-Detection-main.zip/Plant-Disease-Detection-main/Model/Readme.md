# 🌟Model Architecture :
<center><img src ="model.JPG"></center>

## 🌟NOTE :-
<ul>
  <li>If pdf or ipython notebook will not load then please check markdown filde (.md)
  </li>
<li>I am not able to upload a large size model in github repo So you have to trained your model by yourself in your pc/laptop and Save as "plant_disease_model_1_latest.pt"</li>

<li> For flask we use this trained model </li>

<li> Make Sure if you change the model name then also changes required in flask app.py file </li></ul>

## 🌟Blog Link ( Dataset link is in blog ):
<a href="https://medium.com/analytics-vidhya/plant-disease-detection-using-convolutional-neural-networks-and-pytorch-87c00c54c88f" target="_blank">Plant Disease Detection using Convolutional Neural Network with PyTorch Implementation</a>
